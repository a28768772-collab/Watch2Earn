package com.watch2earn.app

import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private var points = 0
    private val rupees: String get() = String.format("%.2f", points / 1000.0)
    private lateinit var balance: TextView
    private lateinit var status: TextView

    private fun tv(text: String, size: Float = 16f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(25,25,25))
            setPadding(20, 16, 20, 16)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(Color.WHITE)
    }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun showHome() {
        val root = base()
        root.addView(tv("WATCH2EARN", 28f))
        root.addView(tv("Watch • Earn Points • Redeem Rewards", 16f))

        balance = tv("💎 $points Points    •    ₹$rupees", 22f)
        root.addView(balance)

        status = tv("Complete a video to earn points.", 15f)
        root.addView(status)

        root.addView(button("🎬 Watch & Earn") { showWatch() })
        root.addView(button("💰 Wallet") { showWallet() })
        root.addView(button("📜 Earning History") {
            Toast.makeText(this, "History will appear here in the next version.", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("🏧 Withdrawal") { showWithdraw() })
        root.addView(button("👤 Profile") {
            Toast.makeText(this, "Profile: Guest user", Toast.LENGTH_SHORT).show()
        })
        setContentView(root)
    }

    private fun showWatch() {
        val root = base()
        root.addView(tv("🎬 Watch & Earn", 26f))
        root.addView(tv("Demo reward: 100 Points after the timer finishes.\n1000 Points = ₹1", 17f))

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 15
        progress.progress = 0
        root.addView(progress, ViewGroup.LayoutParams(-1, 60))

        val countdown = tv("Ready", 18f)
        root.addView(countdown)

        val watch = button("▶ Start Video") {}
        root.addView(watch)
        root.addView(button("← Back") { showHome() })

        watch.setOnClickListener {
            watch.isEnabled = false
            var sec = 15
            countdown.text = "Watching… $sec seconds"
            object : CountDownTimer(15000, 1000) {
                override fun onTick(ms: Long) {
                    sec = max(0, (ms / 1000).toInt())
                    countdown.text = "Watching… $sec seconds"
                    progress.progress = 15 - sec
                }
                override fun onFinish() {
                    progress.progress = 15
                    points += 100
                    countdown.text = "✅ Completed! +100 Points"
                    watch.text = "Completed"
                    showBalanceRefresh()
                }
            }.start()
        }
        setContentView(root)
    }

    private fun showBalanceRefresh() {
        // The current screen is refreshed only when returning home.
        status?.text = "Points updated. Return to Home to see your balance."
    }

    private fun showWallet() {
        val root = base()
        root.addView(tv("💰 My Wallet", 26f))
        root.addView(tv("Points: $points", 22f))
        root.addView(tv("Value: ₹$rupees", 22f))
        root.addView(tv("Conversion: 1,000 Points = ₹1", 16f))
        root.addView(button("🏧 Withdraw") { showWithdraw() })
        root.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showWithdraw() {
        val root = base()
        root.addView(tv("🏧 Withdrawal", 26f))
        root.addView(tv("Current balance: $points Points = ₹$rupees", 18f))
        root.addView(tv("Minimum withdrawal in this demo: 10,000 Points (₹10)", 15f))

        val input = EditText(this).apply {
            hint = "Enter UPI ID"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        root.addView(input)

        root.addView(button("Request Withdrawal") {
            if (points < 10000) {
                Toast.makeText(this, "Minimum 10,000 Points required.", Toast.LENGTH_LONG).show()
            } else if (input.text.toString().trim().isEmpty()) {
                Toast.makeText(this, "Please enter your UPI ID.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Withdrawal request submitted.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(button("← Back") { showHome() })
        setContentView(root)
    }
}
