package com.watch2earn.app

import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var points=0
    private val rupees get()=String.format("%.2f",points/1000.0)

    private fun tv(s:String,size:Float=16f)=TextView(this).apply {
        text=s; textSize=size; setTextColor(Color.DKGRAY); setPadding(20,16,20,16)
    }
    private fun base()=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24)
    }
    private fun btn(s:String, f:()->Unit)=Button(this).apply { text=s; setOnClickListener{f()} }

    override fun onCreate(b:Bundle?){super.onCreate(b);home()}

    private fun home(){
        val r=base()
        r.addView(tv("WATCH2EARN",28f))
        r.addView(tv("Watch • Earn Points • Redeem Rewards"))
        r.addView(tv("💎 $points Points   •   ₹$rupees",22f))
        r.addView(btn("🎬 Watch & Earn"){watch()})
        r.addView(btn("💰 Wallet"){wallet()})
        r.addView(btn("🏧 Withdrawal"){withdraw()})
        r.addView(btn("📜 Earning History"){Toast.makeText(this,"History will be added with the secure backend.",Toast.LENGTH_SHORT).show()})
        r.addView(btn("👤 Profile"){Toast.makeText(this,"Guest user",Toast.LENGTH_SHORT).show()})
        setContentView(r)
    }

    private fun watch(){
        val r=base()
        r.addView(tv("🎬 Watch & Earn",26f))
        r.addView(tv("Demo: complete the timer to receive 100 Points.\n1,000 Points = ₹1"))
        val p=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal)
        p.max=15; r.addView(p,ViewGroup.LayoutParams(-1,60))
        val status=tv("Ready",18f); r.addView(status)
        val b=btn("▶ Start Video"){}
        r.addView(b); r.addView(btn("← Back"){home()})
        b.setOnClickListener{
            b.isEnabled=false
            object:CountDownTimer(15000,1000){
                override fun onTick(ms:Long){val s=(ms/1000).toInt();status.text="Watching… $s seconds";p.progress=15-s}
                override fun onFinish(){p.progress=15;points+=100;status.text="✅ Completed! +100 Points";b.text="Completed"}
            }.start()
        }
        setContentView(r)
    }

    private fun wallet(){
        val r=base()
        r.addView(tv("💰 My Wallet",26f))
        r.addView(tv("Points: $points",22f))
        r.addView(tv("Value: ₹$rupees",22f))
        r.addView(tv("Conversion: 1,000 Points = ₹1"))
        r.addView(btn("🏧 Withdraw"){withdraw()})
        r.addView(btn("← Back"){home()})
        setContentView(r)
    }

    private fun withdraw(){
        val r=base()
        r.addView(tv("🏧 Withdrawal",26f))
        r.addView(tv("Balance: $points Points = ₹$rupees"))
        r.addView(tv("Minimum: 10,000 Points = ₹10"))
        val e=EditText(this); e.hint="Enter UPI ID"; r.addView(e)
        r.addView(btn("Request Withdrawal"){
            if(points<10000) Toast.makeText(this,"Minimum 10,000 Points required.",Toast.LENGTH_LONG).show()
            else if(e.text.toString().trim().isEmpty()) Toast.makeText(this,"Enter UPI ID.",Toast.LENGTH_SHORT).show()
            else Toast.makeText(this,"Request submitted.",Toast.LENGTH_LONG).show()
        })
        r.addView(btn("← Back"){home()})
        setContentView(r)
    }
}
