package com.watch2earn.app

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private var points = 0
    private val rupees get() = String.format("%.2f", points / 1000.0)
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(20, 21, 27)
    private val text = Color.WHITE
    private val muted = Color.rgb(170, 173, 184)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun tv(s: String, size: Float = 16f, color: Int = text, bold: Boolean = false) = TextView(this).apply {
        this.text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        includeFontPadding = false
    }

    private fun rounded(color: Int, radius: Int = 16) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun gradient(a: Int, b: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)
    ).apply { cornerRadius = dp(14).toFloat() }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        home()
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        fitsSystemWindows = true
    }

    private fun topBar(parent: LinearLayout) {
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }
        val search = TextView(this).apply {
            text = "⌕  Search series, episodes..."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.rgb(30, 31, 36), 22)
            setPadding(dp(16), 0, dp(12), 0)
        }
        bar.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f))
        val vip = tv("♛", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(dp(10),0,dp(4),0) }
        bar.addView(vip, LinearLayout.LayoutParams(dp(46), dp(46)))
        val gift = tv("🎁", 22f).apply { gravity = Gravity.CENTER; setPadding(dp(6),0,0,0) }
        bar.addView(gift, LinearLayout.LayoutParams(dp(42), dp(46)))
        parent.addView(bar)
    }

    private fun tabs(parent: LinearLayout) {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), 0, dp(12), dp(8)) }
        val names = listOf("खोजें", "नई सीरीज", "डब्ड सीरीज", "श्रेणियां", "रैंकिंग", "ऐप")
        names.forEachIndexed { i, n ->
            val t = tv(n, if (i == 0) 18f else 17f, if (i == 0) Color.WHITE else muted, i == 0)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)))
        }
        scroll.addView(row)
        parent.addView(scroll)
    }

    private fun chipRow(parent: LinearLayout) {
        val row = LinearLayout(this).apply { setPadding(dp(12), 0, dp(12), dp(10)); gravity = Gravity.CENTER_VERTICAL }
        listOf("लोकप्रिय", "शक्तिशाली", "पछतावे का प्यार", "निष्क्रिय").forEachIndexed { i, s ->
            val c = tv(s, 13f, if (i == 0) Color.WHITE else muted, i == 0)
            c.gravity = Gravity.CENTER
            c.background = if (i == 0) rounded(Color.rgb(39, 40, 46), 20) else null
            c.setPadding(dp(15), dp(7), dp(15), dp(7))
            row.addView(c)
        }
        parent.addView(row)
    }

    private data class Card(val title: String, val tag: String, val genre: String, val count: String, val c1: Int, val c2: Int)

    private fun cards(parent: LinearLayout) {
        val grid = GridLayout(this).apply {
            columnCount = 2
            setPadding(dp(10), 0, dp(10), dp(6))
        }
        val data = listOf(
            Card("Iron Fist Yodha", "डबिंग", "निष्कम्मा से बादशाह", "56K", 0xff172238.toInt(), 0xff6b2b2b.toInt()),
            Card("ड्रैगनबॉर्न", "लोकप्रिय श्रृंखला", "सस्पेंस • बदला", "107.1K", 0xff34220f.toInt(), 0xff8b2d22.toInt()),
            Card("वो मंगेतर नहीं, मेरा डॉन पति", "नई श्रृंखला", "प्यारा रोमांस", "45K", 0xff28162a.toInt(), 0xffa63f45.toInt()),
            Card("दुनिया का सबसे बड़ा आवारा 3", "डबिंग", "एक्शन • बदला", "61.3K", 0xff101e30.toInt(), 0xff335d75.toInt()),
            Card("ताकत का खेल", "लोकप्रिय श्रृंखला", "ड्रामा", "576.5K", 0xff3a231a.toInt(), 0xff8c4c2b.toInt()),
            Card("Pataal Ka Barista", "डब्ड", "फैंटेसी कल्पना", "40.1K", 0xff17172e.toInt(), 0xff244e74.toInt()),
            Card("निकम्मा पति निकला समुद्र का देव", "डबिंग", "फैंटेसी", "39.8K", 0xff12252b.toInt(), 0xff31566d.toInt()),
            Card("बेटी के खून पर सिंहासन", "नई श्रृंखला", "रोमांस • बदला", "52.4K", 0xff2a1822.toInt(), 0xff5b3547.toInt()),
            Card("सुपर मॉम की वापसी", "नई श्रृंखला", "परिवार", "31K", 0xff39220f.toInt(), 0xff8b4e28.toInt()),
            Card("डबल लाइफ बॉस", "लोकप्रिय", "रोमांस", "28K", 0xff182631.toInt(), 0xff3d5d75.toInt())
        )
        data.forEach { card ->
            val view = cardView(card)
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(238)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            grid.addView(view, lp)
        }
        parent.addView(grid)
    }

    private fun cardView(card: Card): FrameLayout {
        val box = FrameLayout(this).apply { background = gradient(card.c1, card.c2) }
        val glow = tv("✦", 56f, Color.argb(70,255,255,255)).apply { gravity = Gravity.TOP or Gravity.RIGHT; setPadding(0, dp(5), dp(8), 0) }
        box.addView(glow, FrameLayout.LayoutParams(-1, dp(70)))
        val title = tv(card.title, 19f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        box.addView(title, FrameLayout.LayoutParams(-1, dp(110), Gravity.TOP))
        val tag = tv(card.tag, 10f, Color.WHITE, true).apply {
            background = rounded(0xff5f6de8.toInt(), 5); gravity = Gravity.CENTER; setPadding(dp(6),0,dp(6),0)
        }
        val tagLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(25), Gravity.TOP or Gravity.RIGHT)
        tagLp.setMargins(0, dp(7), dp(7), 0)
        box.addView(tag, tagLp)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(8), dp(9)) }
        bottom.addView(tv(card.title, 14f, Color.WHITE, true))
        bottom.addView(tv(card.genre, 11f, 0xffd5d5d8.toInt()))
        bottom.addView(tv("🔥 ${card.count}", 11f, Color.WHITE))
        val blp = FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM)
        box.addView(bottom, blp)
        box.setOnClickListener { watch(card.title) }
        return box
    }

    private fun bottomNav(parent: LinearLayout) {
        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(7), dp(4), dp(7))
            background = ColorDrawableCompat.color(0xff111217.toInt())
        }
        val items = listOf("⌂\nहोम", "▣\nसुझाव", "◉\nलाभ", "♡\nफॉलो", "◯\nमेरा")
        items.forEachIndexed { i, s ->
            val b = tv(s, 12f, if (i == 0) Color.WHITE else muted, i == 0).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(2)) }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(56), 1f))
            b.setOnClickListener { if (i == 2) wallet() else if (i == 4) profile() }
        }
        parent.addView(nav, LinearLayout.LayoutParams(-1, dp(64)))
    }

    private fun home() {
        val root = root()
        topBar(root); tabs(root); chipRow(root)
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cards(content)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        bottomNav(root)
        setContentView(root)
    }

    private fun screen(title: String): LinearLayout = root().apply {
        val head = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10)) }
        val back = tv("‹", 36f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        head.addView(back, LinearLayout.LayoutParams(dp(50), dp(50)))
        head.addView(tv(title, 23f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(50), 1f))
        back.setOnClickListener { home() }
        addView(head)
    }

    private fun watch(name: String = "Selected series") {
        val r = screen("Watch & Earn")
        r.addView(tv("🎬  $name", 22f, Color.WHITE, true).apply { setPadding(dp(18), dp(10), dp(18), dp(10)) })
        r.addView(tv("वीडियो पूरा देखें और 100 Points कमाएँ.\n1,000 Points = ₹1", 16f, muted).apply { setPadding(dp(18), dp(6), dp(18), dp(20)) })
        val p = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 15 }
        r.addView(p, LinearLayout.LayoutParams(-1, dp(18)).apply { setMargins(dp(18),0,dp(18),dp(18)) })
        val status = tv("Ready", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20)) }
        r.addView(status)
        val b = Button(this).apply { text = "▶  Start Watching" }
        r.addView(b, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(dp(18),0,dp(18),dp(12)) })
        b.setOnClickListener {
            b.isEnabled = false
            object : CountDownTimer(15000, 1000) {
                override fun onTick(ms: Long) { val s = (ms/1000).toInt(); status.text = "Watching… $s seconds"; p.progress = 15-s }
                override fun onFinish() { p.progress=15; points+=100; status.text="✅ Completed! +100 Points"; b.text="Completed" }
            }.start()
        }
        r.addView(tv("Your balance: 💎 $points  •  ₹$rupees", 17f, Color.WHITE).apply { gravity=Gravity.CENTER; setPadding(0,dp(18),0,0) })
        setContentView(r)
    }

    private fun wallet() {
        val r = screen("Wallet")
        r.addView(tv("💎 $points Points", 28f, Color.WHITE, true).apply { setPadding(dp(20),dp(25),dp(20),dp(8)) })
        r.addView(tv("₹$rupees available value", 20f, muted).apply { setPadding(dp(20),0,dp(20),dp(20)) })
        r.addView(tv("1,000 Points = ₹1", 16f, muted).apply { setPadding(dp(20),0,dp(20),dp(25)) })
        r.addView(Button(this).apply { text="🏧  Withdrawal"; setOnClickListener{withdraw()} }, LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(dp(18),0,dp(18),dp(10))})
        setContentView(r)
    }

    private fun withdraw() {
        val r = screen("Withdrawal")
        r.addView(tv("Balance: $points Points = ₹$rupees", 20f, Color.WHITE).apply { setPadding(dp(20),dp(18),dp(20),dp(8)) })
        r.addView(tv("Minimum 10,000 Points = ₹10", 15f, muted).apply { setPadding(dp(20),0,dp(20),dp(18)) })
        val e=EditText(this).apply { hint="Enter UPI ID"; setTextColor(Color.WHITE); setHintTextColor(muted); background=rounded(panel,12); setPadding(dp(14),0,dp(14),0) }
        r.addView(e, LinearLayout.LayoutParams(-1,dp(55)).apply{setMargins(dp(18),0,dp(18),dp(12))})
        r.addView(Button(this).apply { text="Request Withdrawal"; setOnClickListener{
            if(points<10000) Toast.makeText(this@MainActivity,"Minimum 10,000 Points required.",Toast.LENGTH_LONG).show()
            else if(e.text.toString().trim().isEmpty()) Toast.makeText(this@MainActivity,"Enter UPI ID.",Toast.LENGTH_SHORT).show()
            else Toast.makeText(this@MainActivity,"Request submitted.",Toast.LENGTH_LONG).show()
        }}, LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(dp(18),0,dp(18),dp(10))})
        setContentView(r)
    }

    private fun profile() {
        val r = screen("Profile")
        r.addView(tv("👤  Guest User", 24f, Color.WHITE, true).apply{setPadding(dp(20),dp(24),dp(20),dp(10))})
        r.addView(tv("Watch series, earn points and redeem rewards.", 16f, muted).apply{setPadding(dp(20),0,dp(20),dp(20))})
        setContentView(r)
    }

    private object ColorDrawableCompat {
        fun color(c: Int): android.graphics.drawable.ColorDrawable = android.graphics.drawable.ColorDrawable(c)
    }
}
